
const venom = require('venom-bot');
const fs = require('fs');

venom.create().then((client) => start(client));

function start(client) {
  client.onMessage(async (message) => {
    if (message.body === '.menu') {
      client.sendText(message.from, '🔥 Lord Tony Bot Menu 🔥\n1. .ttt - Play Tic Tac Toe\n2. .aza - Show account info\n3. .otp - Generate OTP');
    } else if (message.body === '.otp') {
      const otp = Math.floor(100000 + Math.random() * 900000);
      client.sendText(message.from, `🔐 Your OTP is: ${otp}`);
    } else if (message.body === '.aza') {
      client.sendText(message.from, '🏦 Kuda: 2073507268\n💸 Opay: 08076148890');
    }
  });
}
