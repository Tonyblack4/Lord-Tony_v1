
# Lord Tony Bot 🤖

A WhatsApp bot powered by Venom. Includes commands:
- `.menu` – Show menu
- `.otp` – Send one-time password
- `.aza` – Display account info
- `.ttt` – Play tic tac toe (coming soon)

### Deploying
Install dependencies:
```
npm install
```

Start bot:
```
npm start
```
